<?php
// session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>OTOCHATLUONG</title> -->
</head>
<body>
    <?php

        include_once("trangchu.php");
        // if(isset($_GET["dangnhap"])){
        //     include_once("view/dangnhap.php");
        // }
        // elseif(isset($_GET["chitietsanpham"])){
        //     include_once("view/chitietsanpham/index.php");
        // }elseif(isset($_GET["dangky"])){
        //     include_once("view/dangky/index.php");
        // }else{
        //     include_once("view/SanPham/index.php");
        // }        
        // include_once("view/giaodien/footer.php");
        // ob_end_flush();
    ?>

</html>